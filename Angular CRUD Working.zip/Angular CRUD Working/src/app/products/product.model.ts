export interface Product {
    id: undefined;
    name: string;
  }